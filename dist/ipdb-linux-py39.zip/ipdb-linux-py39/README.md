# iPdbFreeInstall

Offline ipdb bundles for Linux Python 3.6, 3.7, 3.9, and 3.10.
Python itself is not included. Use the interpreter already on your machine.

## Download and run

Download the matching ZIP from the repository dist directory and extract it.
For Python 3.7, for example:

    unzip ipdb-linux-py37.zip
    cd ipdb-linux-py37
    IPDB_PYTHON=python3.7 sh ipdb.sh /path/to/your_script.py

No pip installation or network connection is needed on the destination.
Without IPDB_PYTHON, the launcher selects python3, then python from PATH.
Use a matching interpreter; each archive contains one version's dependencies.
The Linux bundles contain pure-Python wheels and include pexpect/ptyprocess.

| Python | Archive | IPython |
| --- | --- | --- |
| 3.6 | dist/ipdb-linux-py36.zip | 7.16.3 |
| 3.7 | dist/ipdb-linux-py37.zip | 7.34.0 |
| 3.9 | dist/ipdb-linux-py39.zip | 8.18.1 |
| 3.10 | dist/ipdb-linux-py310.zip | 8.18.1 |

All bundles include ipdb 0.13.13, dependency metadata, upstream licenses,
requirements.lock, and wheel-sha256.json. SHA256SUMS covers the archives.

## In-code breakpoints

Add the extracted bundle directory to sys.path, then:

    import portable_ipdb
    import ipdb
    ipdb.set_trace()

Commands: n (next), s (step), c (continue), p expression, q (quit).

## Prepare from source

A source checkout alone does not activate bundled dependencies. Extract the
matching archive, or on a connected machine run the matching interpreter:

    python3.7 prepare.py

This writes vendor/linux-py37 without changing global Python packages.
On Windows, prepare with your Windows interpreter and run ipdb.cmd.
Linux bundles are not Windows dependency bundles.

## Rebuild Linux archives

On the build machine, Python 3.9 and pip are required:

    python build_linux.py

The builder evaluates dependency markers for each target Linux/Python
combination, checks Requires-Python and dependency version constraints,
and includes only pure-Python wheels. It downloads from the HTTPS Aliyun
mirror. Build artifacts are stored in build/ and archives in dist/.

## Validation limits

Archive integrity and target dependency metadata are checked during build.
Native Linux execution and Python 3.6/3.7/3.10 runtime tests have not been
performed in the Windows build environment. Report the full traceback,
Python version, and archive name if a target runtime issue occurs.

Upstream: https://pypi.org/project/ipdb/ and https://github.com/gotcha/ipdb

## Split-screen mode (Linux)

    IPDB_PYTHON=python3.7 sh ipdb.sh --tui /path/to/main.py

The top half follows the selected source frame. The bottom half contains
ipdb commands and live program stdout/stderr. Press Ctrl-X, then A to toggle
the source pane (Ctrl-X Ctrl-A also works). Ctrl-L redraws the display.
Normal n/s/c/p/b/u/d/q commands remain available. Ctrl-C goes to the debuggee.
Resizing the terminal adjusts both panes. Below 10 terminal rows, the source
pane is hidden. --plain selects the original scrolling debugger.

This mode requires an interactive Linux ANSI terminal, such as xterm or a
normal SSH terminal. Redirected input/output and TERM=dumb are not supported.
The debuggee runs in a pseudo-terminal with simple prompts. Full-screen
programs that manipulate terminal cursor positions are not supported.
The source pane shows a window around the current line; unavailable source
(e.g. dynamically generated code) leaves it blank. Switching layout clears
the visible command area; it is not a persistent output log.

To stop at an in-code ipdb.set_trace(), launch the script using --tui and
continue to the desired breakpoint. Importing portable_ipdb alone does not
start the split-screen interface.

Run python -m unittest test_split.py on Linux with the matching dependencies
prepared in vendor. The Linux PTY test checks source display, stepping,
variable inspection, toggling, program output, and debugger exit.

## PuDB mode

The offline archives now include PuDB: version 2020.1 for Python 3.6 and
2022.1 for Python 3.7/3.9/3.10, with Urwid 2.1.2 in pure-Python mode.
No additional installation is required.

    IPDB_PYTHON=python3.7 sh ipdb.sh --pudb /path/to/main.py

Or start --tui, stop at an empty ipdb prompt, then press Ctrl-X followed
by S (Ctrl-X Ctrl-S also works). This hands the current paused session to
PuDB without restarting the script. Use PuDB's n/s/c/b and ? commands.
The PuDB mode remains active for subsequent stops; this shortcut is a
one-way handoff, not a toggle back to ipdb. Ctrl-X A is available only in
the ipdb split view. While the program is running, pause it before using
the PuDB shortcut. Existing ipdb breakpoints are shared with PuDB.

The terminal handoff remains pending native Linux verification. The local
checks cover key decoding and package dependency integrity.
